
console.log("Witaj! zgadnij numer 0-20!")

function numberFromUser() 
{
    let numbers = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
    let randomNumber = Math.floor(Math.random() * numbers.length)
    let counter = document.querySelector('#numberfromuser')

    if (counter.value > numbers[randomNumber]) {
        console.log('nizej')
    }
    else if (counter.value == numbers[randomNumber]) {
        console.log('idealnie')
    }
    else if (counter.value < numbers[randomNumber]) {
        console.log('wyzej')
    }
}