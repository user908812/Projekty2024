const stats = {
    wins: 0,
    loses: 0,
    ties: 0
}

// if (stats.wins >= 5) {
//     alert('Wow! dobrze ci idzie! właśnie zdobyłeś/aś 10 wygranych!')
// }

function papier()
{
    const botChooseOptions = [`✋`, `👊`, `✌️`]
    const randomBotOption = Math.floor(Math.random() * botChooseOptions.length)

    if (botChooseOptions[randomBotOption] == `✋`) {
        stats.ties += 1;
        let reply = document.querySelector(`.reply`).innerText = `Ty: ✋\n Bot: ${botChooseOptions[randomBotOption]}\n\nremis! (papier = papier) \n wygrane: ${stats.wins}\nprzegrane: ${stats.loses}\nremisy: ${stats.ties}`;
    }
    if (botChooseOptions[randomBotOption] == `👊`) {
        stats.wins += 1;
        let reply = document.querySelector(`.reply`).innerText = `Ty: ✋\n Bot: ${botChooseOptions[randomBotOption]}\n\nwygrywasz! (papier > kamien) \n wygrane: ${stats.wins}\nprzegrane: ${stats.loses}\nremisy: ${stats.ties}`;
    }
    if (botChooseOptions[randomBotOption] == `✌️`) {
        stats.loses += 1;
        let reply = document.querySelector(`.reply`).innerText = `Ty: ✋\n Bot: ${botChooseOptions[randomBotOption]}\n\nbot wygrywa! (papier < nozyce) \n wygrane: ${stats.wins}\nprzegrane: ${stats.loses}\nremisy: ${stats.ties}`;
    }
}
function kamien()
{
    const botChooseOptions = [`✋`, `👊`, `✌️`]
    const randomBotOption = Math.floor(Math.random() * botChooseOptions.length)

    if (botChooseOptions[randomBotOption] == `✋`) {
        stats.loses += 1;
        let reply = document.querySelector(`.reply`).innerText = `Ty: 👊\n Bot: ${botChooseOptions[randomBotOption]}\n\nbot wygrywa! (kamien < papier) \n wygrane: ${stats.wins}\nprzegrane: ${stats.loses}\nremisy: ${stats.ties}`;
    }
    if (botChooseOptions[randomBotOption] == `👊`) {
        stats.ties += 1;
        let reply = document.querySelector(`.reply`).innerText = `Ty: 👊\n Bot: ${botChooseOptions[randomBotOption]}\n\nremis! (kamien = kamien) \n wygrane: ${stats.wins}\nprzegrane: ${stats.loses}\nremisy: ${stats.ties}`;
    }
    if (botChooseOptions[randomBotOption] == `✌️`) {
        stats.wins += 1;
        let reply = document.querySelector(`.reply`).innerText = `Ty: 👊\n Bot: ${botChooseOptions[randomBotOption]}\n\nwygrywasz! (kamien > nozyce) \n wygrane: ${stats.wins}\nprzegrane: ${stats.loses}\nremisy: ${stats.ties}`;
    }
}
function nozyce()
{
    const botChooseOptions = [`✋`, `👊`, `✌️`]
    const randomBotOption = Math.floor(Math.random() * botChooseOptions.length)

    if (botChooseOptions[randomBotOption] == `✋`) {
        stats.wins += 1;
        let reply = document.querySelector(`.reply`).innerText = `Ty: ✌️\n Bot: ${botChooseOptions[randomBotOption]}\n\nwygrywasz! (nozyce > papier) \n wygrane: ${stats.wins}\nprzegrane: ${stats.loses}\nremisy: ${stats.ties}`;
    }
    if (botChooseOptions[randomBotOption] == `👊`) {
        stats.loses += 1;
        let reply = document.querySelector(`.reply`).innerText = `Ty: ✌️\n Bot: ${botChooseOptions[randomBotOption]}\n\nbot wygrywa! (nozyce < kamien) \n wygrane: ${stats.wins}\nprzegrane: ${stats.loses}\nremisy: ${stats.ties}`;
    }
    if (botChooseOptions[randomBotOption] == `✌️`) {
        
        let reply = document.querySelector(`.reply`).innerText = `Ty: ✌️\n Bot: ${botChooseOptions[randomBotOption]}\n\nremis! (nozyce = nozyce) \n wygrane: ${stats.wins}\nprzegrane: ${stats.loses}\nremisy: ${stats.ties}`;
    }
}
function reset()
{
    document.querySelector('.reply').innerText = '';
    stats.wins = stats.loses = stats.ties = 0
}
function changeBackground()
{
    document.querySelector('.bgchanger').addEventListener('click', (event) => {
        let colors = ['red', 'salmon', 'orangered', 'yellow', 'lightgreen',
        'green', 'darksalmon', 'darkolivegreen', 'cyan', 'darkgoldenrod', 'crimson', 'cadetblue', 'chartreuse', 'cornflowerblue', 'coral', 'aquamarine', 'lightblue', 'blue', 'purple', 'grey', 'brown', 'black']
        let randomColor = Math.floor(Math.random() * colors.length)
        document.body.style.backgroundColor = colors[randomColor]
    })
}
    document.body.addEventListener('keydown', (event) => {
        if (event.key == 'p') {
            papier()
        }
    })
    document.body.addEventListener('keydown', (event) => {
        if (event.key == 'k') {
            kamien()
        }
    })
    document.body.addEventListener('keydown', (event) => {
        if (event.key == 'n') {
            nozyce()
        }
    })
    document.body.addEventListener('keydown', (event) => {
        if (event.key == 'r') {
            reset()
        }
    })
    document.body.addEventListener('keydown', (event) => {
        if (event.key == 't') {
            let colors = ['red', 'salmon', 'orangered', 'yellow', 'lightgreen',
            'green', 'darksalmon', 'darkolivegreen', 'cyan', 'darkgoldenrod', 'crimson', 'cadetblue', 'chartreuse', 'cornflowerblue', 'coral', 'aquamarine', 'lightblue', 'blue', 'purple', 'grey', 'brown', 'black']
            let randomColor = Math.floor(Math.random() * colors.length)
            document.body.style.backgroundColor = colors[randomColor]
        }
    })
    document.body.addEventListener('keydown', (event) => {
        if (event.key == 'd') {
            document.body.style.backgroundColor = '#000';
            document.body.style.color = '#fff';
        }
    })
    document.body.addEventListener('keydown', (event) => {
        if (event.key == 'l') {
            document.body.style.backgroundColor = '#fff';
            document.body.style.color = 'grey';
        }
    })